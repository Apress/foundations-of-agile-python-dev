Coverage: code coverage testing for Python

Coverage.py is a Python module that measures code coverage during test execution.
It uses the code analysis tools and tracing hooks provided in the Python standard
library to determine which lines are executable, and which have been executed.

For more information, see http://nedbatchelder.com/code/modules/coverage.html
