from twisted.trial import unittest

class TestTwisted(unittest.TestCase):

    def test(self):
        pass

