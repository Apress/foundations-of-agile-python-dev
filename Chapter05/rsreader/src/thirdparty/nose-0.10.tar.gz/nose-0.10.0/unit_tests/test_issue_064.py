def test_is_generator_alias():
    from nose.util import is_generator, isgenerator
